# Zigbee NVS Save/Restore POC — ESP32 + Wokwi + Postgres (VS Code, no hardware)

## 0. What this demo actually does, and one important limitation

**Wokwi does not simulate the 802.15.4/Zigbee radio.** Its own ESP32
feature-support table lists WiFi as simulated but has no row for Zigbee
or 802.15.4 at all (Bluetooth is listed as *not implemented* either) —
this is true for every ESP32 variant Wokwi supports, including the
ESP32-C6 and ESP32-H2. So two virtual devices cannot actually form or
join a Zigbee network inside Wokwi.

What we *can* do, and what this POC does:

1. **Device A ("writer")** — populates its own NVS with the same fields
   a real ESP Zigbee SDK stack would have already written after a
   successful join (extended PAN ID, channel, network key, TC link key,
   short address). Think of this as "device already commissioned."
   It then reads that blob back out of NVS and uploads it to a small
   REST API, which stores it in **Postgres**.
2. **Device B ("reader")** — downloads that same blob from Postgres over
   HTTP and writes it into **its own** NVS, in the same partition/
   namespace a real Zigbee stack reads from at boot. It then reads it
   back to prove the restore worked.

Both devices talk over **WiFi**, which Wokwi *does* fully simulate —
so the "save to Postgres / restore from Postgres" mechanic, which is
the actual point of the demo, works exactly like it would on real
hardware. Only the "join a live Zigbee network" part is stand-in data.

```
 ┌────────────┐   WiFi/HTTP    ┌────────────┐    SQL    ┌──────────┐
 │ Device A   │ ─────────────▶ │  FastAPI   │ ────────▶ │ Postgres │
 │ (Wokwi     │  POST /save    │  backend   │           │          │
 │  ESP32)    │                └────────────┘           └──────────┘
 └────────────┘                       ▲
                                       │ GET /load
 ┌────────────┐   WiFi/HTTP           │
 │ Device B   │ ───────────────────────┘
 │ (Wokwi     │
 │  ESP32)    │
 └────────────┘
```

Folder layout (already created for you):

```
zigbee-nvs-postgres-poc/
├── README.md                 <- this file
├── backend/                  <- Postgres + FastAPI bridge
│   ├── app.py
│   ├── requirements.txt
│   ├── schema.sql
│   └── docker-compose.yml
├── device-a-writer/          <- ESP-IDF project #1 (Wokwi-simulated)
│   ├── CMakeLists.txt
│   ├── sdkconfig.defaults
│   ├── partitions.csv
│   ├── wokwi.toml
│   ├── diagram.json
│   └── main/
│       ├── CMakeLists.txt
│       └── main.c
└── device-b-reader/          <- ESP-IDF project #2 (Wokwi-simulated)
    └── (same layout as above)
```

---

## 1. Install VS Code and the required extensions

1. Download and install **Visual Studio Code**: https://code.visualstudio.com/
2. Open VS Code → click the **Extensions** icon in the left sidebar
   (or `Ctrl+Shift+X` / `Cmd+Shift+X`).
3. Install these three extensions:
   - **"ESP-IDF"** by Espressif Systems — this gives you ESP-IDF project
     creation, build, and debugging support inside VS Code.
   - **"Wokwi Simulator"** by Wokwi — this is the simulator extension
     that lets you run the compiled firmware without any hardware.
   - **"C/C++"** by Microsoft — for IntelliSense while editing `main.c`.

---

## 2. Install ESP-IDF itself (one-time setup)

1. Press `F1` (or `Ctrl+Shift+P`) → type **"ESP-IDF: Configure ESP-IDF
   Extension"** → press Enter.
2. Choose **"Express"** setup.
3. Pick the ESP-IDF version (v5.x is fine — this demo doesn't need any
   Zigbee-specific component).
4. Pick an install directory and let it download the toolchain, Python
   environment, and ESP-IDF source. This step needs internet access and
   can take several minutes the first time.
5. When it finishes, you should see "ESP-IDF" in the VS Code status bar
   at the bottom.

---

## 3. Get a Wokwi license for VS Code (free, no hardware needed)

1. Press `F1` → **"Wokwi: Request a New License"**.
2. Follow the browser prompt (sign in with GitHub) to get a free
   personal-use license, valid 30 days, renewable.
3. Paste the license key back into VS Code when prompted.

You now have everything needed to build and simulate ESP32 firmware
with **zero physical hardware**.

---

## 4. Start Postgres and the backend API

You can either use the files already provided in `backend/`, or type
these commands yourself in a VS Code terminal.

```bash
cd zigbee-nvs-postgres-poc/backend

# Start Postgres in Docker
docker compose up -d

# Create a Python virtual environment and install deps
python3 -m venv venv
source venv/bin/activate          # on Windows: venv\Scripts\activate
pip install -r requirements.txt

# Run the API, bound to 0.0.0.0 so the simulator can reach it
uvicorn app:app --host 0.0.0.0 --port 8000
```

Leave this terminal running. Verify it's up:

```bash
curl http://localhost:8000/health
# -> {"status":"ok"}
```

**Find your machine's LAN IP** (you'll need it in step 6):

- macOS/Linux: `ifconfig | grep inet` (or `ip addr`)
- Windows: `ipconfig`

You want something like `192.168.1.100` — **not** `127.0.0.1`, because
the Wokwi simulator's virtual WiFi is a separate network namespace and
can't reach `localhost` on your machine directly; it reaches your
machine the same way another device on your LAN would.

---

## 5. Open Device A's project in VS Code

1. `File → Open Folder…` → select `zigbee-nvs-postgres-poc/device-a-writer`.
2. This is a plain ESP-IDF project — that's the "new project" VS Code
   sees. The `wokwi.toml` and `diagram.json` files sitting alongside it
   are what "merges" it with the Wokwi simulator: they tell the Wokwi
   extension which built firmware file to load and what virtual board
   to attach it to, so no physical device is ever required.
   - `diagram.json` → declares a virtual **ESP32 DevKit-C V4** board
     wired to the simulator's virtual serial monitor.
   - `wokwi.toml` → points at `build/flasher_args.json`, the file
     `idf.py build` produces, so the simulator always loads your latest
     compiled firmware automatically.
3. Open `main/main.c` and set your backend's LAN IP:
   ```c
   #define BACKEND_HOST   "192.168.1.100"   // <-- your machine's LAN IP
   ```

---

## 6. Build and simulate Device A

1. Press `F1` → **"ESP-IDF: Set Espressif Device Target"** → choose
   `esp32` (the classic ESP32 — it has the most mature WiFi simulation
   support in Wokwi; the chip choice doesn't matter for the Zigbee-NVS
   part since that's all just NVS + WiFi + HTTP, no radio access).
2. Press `F1` → **"ESP-IDF: Build your Project"** (or click the build
   icon in the status bar). Wait for it to finish — this creates
   `build/flasher_args.json` and the `.elf` file that `wokwi.toml`
   references.
3. Press `F1` → **"Wokwi: Start Simulator"**.
4. A simulator panel opens showing the virtual ESP32 board and a serial
   monitor. You should see log lines like:
   ```
   I (xxx) device_a_writer: Connecting to WiFi SSID:Wokwi-GUEST
   I (xxx) device_a_writer: Got IP: 10.13.37.2
   I (xxx) device_a_writer: Zigbee network info written to 'zb_storage' NVS partition (52 bytes)
   I (xxx) device_a_writer: POST /api/nvs/save -> HTTP 200
   I (xxx) device_a_writer: Done. Check the Postgres 'zigbee_nvs_backup' table for device_id='zigbee-device-A'.
   ```
5. Confirm the row landed in Postgres:
   ```bash
   docker exec -it zigbee_poc_postgres psql -U postgres -d zigbee_poc \
     -c "SELECT device_id, updated_at FROM zigbee_nvs_backup;"
   ```

If the HTTP POST fails or times out, it's almost always the
`BACKEND_HOST` IP — double check it's your LAN IP, that the `uvicorn`
server is bound to `0.0.0.0`, and that your firewall allows inbound
connections on port 8000.

---

## 7. Open, build, and simulate Device B

1. Open a **second** VS Code window: `File → Open Folder…` → select
   `zigbee-nvs-postgres-poc/device-b-reader`.
2. Same as before: open `main/main.c` and set:
   ```c
   #define BACKEND_HOST   "192.168.1.100"   // <-- your machine's LAN IP
   ```
3. `F1` → **"ESP-IDF: Set Espressif Device Target"** → `esp32`.
4. `F1` → **"ESP-IDF: Build your Project"**.
5. `F1` → **"Wokwi: Start Simulator"**.
6. Watch the serial monitor — you should see:
   ```
   I (xxx) device_b_reader: Connecting to WiFi SSID:Wokwi-GUEST
   I (xxx) device_b_reader: Got IP: 10.13.37.2
   I (xxx) device_b_reader: GET http://192.168.1.100:8000/api/nvs/load?device_id=zigbee-device-A -> HTTP 200
   I (xxx) device_b_reader: Restored Zigbee identity from Postgres:
   I (xxx) device_b_reader:   PAN ID:       0x1A62
   I (xxx) device_b_reader:   Channel:      15
   I (xxx) device_b_reader:   Short addr:   0x0000
   I (xxx) device_b_reader:   Device role:  0
   I (xxx) device_b_reader: Verification OK: 'zb_storage'/'zb_data' now holds 52 bytes on Device B
   I (xxx) device_b_reader: Device B is now provisioned with Device A's saved Zigbee identity.
   ```

That confirms the full round trip: Device A's simulated Zigbee NVS data
→ Postgres → Device B's own NVS, entirely through code you can inspect
and modify, with no physical ESP32 boards involved.

---

## 8. Where to go from here (toward real hardware)

- **On real ESP32-H2/C6 hardware**, swap `simulate_zigbee_join_and_persist()`
  in `device-a-writer/main.c` for the actual `esp-zigbee-sdk` join
  callback, and read the real `zb_storage`/`zb_fct` partitions the SDK
  creates instead of the placeholder struct used here. The Postgres
  save/restore plumbing (backend + both firmware's HTTP calls) stays
  identical.
- Add TLS/auth to the FastAPI backend before using it outside a lab
  network — right now it's a plain-HTTP POC.
- Consider encrypting the NVS blob before it leaves the device, since a
  real Zigbee network key is sensitive material.
