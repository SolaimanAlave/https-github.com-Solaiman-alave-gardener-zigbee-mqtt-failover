/*
 * main.c — Board 1 ("esp32c5-01"), Gardener Zigbee network COORDINATOR
 *
 * This firmware:
 *   1. Connects to WiFi
 *   2. Forms a real Zigbee network as coordinator (esp-zigbee-sdk)
 *   3. Persists network info (PAN ID, channel, keys) to NVS on formation
 *   4. Connects to MQTT, publishes periodic heartbeats
 *   5. Subscribes to its own command topic and the network failover
 *      announce topic (a coordinator normally won't be told to become
 *      coordinator, but the handler is included for symmetry/testing)
 *   6. Drives the status LED on GPIO2 (ACTIVE-LOW — LOW turns it on,
 *      per how you wired 3.3V -> resistor -> LED -> GPIO2):
 *        - Solid ON   = coordinator, network formed, MQTT connected
 *        - Slow blink = still forming network / connecting
 *        - OFF        = WiFi/MQTT disconnected
 *
 * Board-specific settings are the four #defines right below.
 */
#include <string.h>
#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_log.h"
#include "esp_event.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "esp_netif.h"
#include "nvs_flash.h"
#include "driver/gpio.h"
#include "mqtt_client.h"
#include "cJSON.h"

#include "esp_zigbee_core.h"
#include "zboss_api.h"



/* ==================== Board-specific settings ===================== */
#define DEVICE_ID          "esp32c5-01"
#define NETWORK_ID          "gardener-main"
#define WIFI_SSID            "Temple"      /* <-- set this */
#define WIFI_PASS             "StThomas$1976"  /* <-- set this */
#define MQTT_BROKER_URI        "mqtt://10.0.0.21:1883"  /* <-- your Mac's LAN IP */
#define ZB_PRIMARY_CHANNEL_MASK  (1 << 15)          /* channel 15, matches Postgres seed */
/* ===================================================================*/

#define STATUS_LED_GPIO     GPIO_NUM_2
#define LED_ON()            gpio_set_level(STATUS_LED_GPIO, 0)   /* active-low */
#define LED_OFF()           gpio_set_level(STATUS_LED_GPIO, 1)

#define ZB_NVS_PART    "zb_storage"
#define ZB_NVS_NS      "zdo"
#define ZB_NVS_KEY     "zb_data"

static const char *TAG = "coordinator";
static EventGroupHandle_t s_wifi_event_group;
#define WIFI_CONNECTED_BIT BIT0

static esp_mqtt_client_handle_t s_mqtt_client;
static volatile bool s_mqtt_connected = false;
static volatile bool s_zigbee_network_formed = false;

/* Same shape as the earlier save/restore POC and mqtt_failover.c —
 * kept as our own record of network identity independent of what the
 * Zigbee stack stores internally, so the MQTT payloads stay simple. */
typedef struct __attribute__((packed)) {
    uint8_t  extended_pan_id[8];
    uint16_t pan_id;
    uint8_t  channel;
    uint8_t  network_key[16];
    uint8_t  tc_link_key[16];
} zigbee_network_config_t;

/* ---------------------------------------------------------------------
 * LED status task — simple pattern: blink while forming, solid once the
 * network is up AND mqtt is connected, off if either drops.
 * ------------------------------------------------------------------- */
static void led_task(void *arg)
{
    gpio_config_t io_conf = {
        .pin_bit_mask = 1ULL << STATUS_LED_GPIO,
        .mode = GPIO_MODE_OUTPUT,
    };
    gpio_config(&io_conf);
    LED_OFF();

    while (1) {
        if (s_zigbee_network_formed && s_mqtt_connected) {
            LED_ON();
            vTaskDelay(pdMS_TO_TICKS(1000));
        } else {
            LED_ON();
            vTaskDelay(pdMS_TO_TICKS(150));
            LED_OFF();
            vTaskDelay(pdMS_TO_TICKS(150));
        }
    }
}

/* ---------------------------------------------------------------------
 * WiFi
 * ------------------------------------------------------------------- */
static void wifi_event_handler(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
   } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
    wifi_event_sta_disconnected_t *disconn = (wifi_event_sta_disconnected_t *) data;
    ESP_LOGW(TAG, "WiFi disconnected, reason: %d, retrying...", disconn->reason);
    s_mqtt_connected = false;
    esp_wifi_connect();
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *event = (ip_event_got_ip_t *) data;
        ESP_LOGI(TAG, "Got IP: " IPSTR, IP2STR(&event->ip_info.ip));
        xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
    }
}

static void wifi_init_sta(void)
{
    s_wifi_event_group = xEventGroupCreate();
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &wifi_event_handler, NULL));

    wifi_config_t wifi_config = {
        .sta = { .ssid = WIFI_SSID, .password = WIFI_PASS,
        .pmf_cfg = {
            .capable = true,
            .required = false,
        },
     },
    };
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());
    

    ESP_LOGI(TAG, "Connecting to WiFi SSID:%s", WIFI_SSID);
    xEventGroupWaitBits(s_wifi_event_group, WIFI_CONNECTED_BIT, pdFALSE, pdTRUE, portMAX_DELAY);
}

/* ---------------------------------------------------------------------
 * NVS helpers (same pattern as the save/restore POC)
 * ------------------------------------------------------------------- */
static void write_network_config_to_nvs(const zigbee_network_config_t *cfg)
{
    nvs_handle_t h;
    ESP_ERROR_CHECK(nvs_open_from_partition(ZB_NVS_PART, ZB_NVS_NS, NVS_READWRITE, &h));
    ESP_ERROR_CHECK(nvs_set_blob(h, ZB_NVS_KEY, cfg, sizeof(*cfg)));
    ESP_ERROR_CHECK(nvs_commit(h));
    nvs_close(h);
    ESP_LOGI(TAG, "Network config written to '%s' NVS partition", ZB_NVS_PART);
}

static void hex_to_bytes(const char *hex, uint8_t *out, size_t out_len)
{
    for (size_t i = 0; i < out_len; i++) {
        sscanf(hex + (i * 2), "%2hhx", &out[i]);
    }
}

/* ---------------------------------------------------------------------
 * MQTT topic helpers
 * ------------------------------------------------------------------- */
static void topic_heartbeat(char *buf, size_t len) {
    snprintf(buf, len, "oxyos/zigbee/%s/devices/%s/heartbeat", NETWORK_ID, DEVICE_ID);
}
static void topic_status(char *buf, size_t len) {
    snprintf(buf, len, "oxyos/zigbee/%s/devices/%s/status", NETWORK_ID, DEVICE_ID);
}
static void topic_command(char *buf, size_t len) {
    snprintf(buf, len, "oxyos/zigbee/%s/devices/%s/command", NETWORK_ID, DEVICE_ID);
}
static void topic_ack(char *buf, size_t len) {
    snprintf(buf, len, "oxyos/zigbee/%s/devices/%s/ack", NETWORK_ID, DEVICE_ID);
}
static void topic_announce(char *buf, size_t len) {
    snprintf(buf, len, "oxyos/zigbee/%s/failover/announce", NETWORK_ID);
}

static void publish_heartbeat(void)
{
    if (!s_mqtt_connected) return;

    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "device_id", DEVICE_ID);
    cJSON_AddStringToObject(root, "role", "coordinator");
    cJSON_AddNumberToObject(root, "uptime_s", (double)(esp_timer_get_time() / 1000000));

    char *body = cJSON_PrintUnformatted(root);
    char topic[128];
    topic_heartbeat(topic, sizeof(topic));
    esp_mqtt_client_publish(s_mqtt_client, topic, body, 0, 1, 0);

    cJSON_Delete(root);
    free(body);
}

static void heartbeat_task(void *arg)
{
    while (1) {
        publish_heartbeat();
        vTaskDelay(pdMS_TO_TICKS(20000)); /* every 20s */
    }
}

/* Handler included for completeness/testing — a normal coordinator
 * shouldn't receive this, but if OxyOS ever needs to force a re-form
 * with specific parameters, this is the entry point. */
static void handle_become_coordinator(cJSON *root)
{
    cJSON *net_cfg = cJSON_GetObjectItem(root, "network_config");
    if (!cJSON_IsObject(net_cfg)) {
        ESP_LOGE(TAG, "become_coordinator: missing network_config");
        return;
    }

    zigbee_network_config_t cfg = {0};
    cJSON *epid = cJSON_GetObjectItem(net_cfg, "extended_pan_id_hex");
    cJSON *pan  = cJSON_GetObjectItem(net_cfg, "pan_id");
    cJSON *chan = cJSON_GetObjectItem(net_cfg, "channel");
    cJSON *nkey = cJSON_GetObjectItem(net_cfg, "network_key_hex");
    cJSON *tckey = cJSON_GetObjectItem(net_cfg, "tc_link_key_hex");

    if (cJSON_IsString(epid)) hex_to_bytes(epid->valuestring, cfg.extended_pan_id, 8);
    if (cJSON_IsNumber(pan))  cfg.pan_id = (uint16_t) pan->valuedouble;
    if (cJSON_IsNumber(chan)) cfg.channel = (uint8_t) chan->valuedouble;
    if (cJSON_IsString(nkey)) hex_to_bytes(nkey->valuestring, cfg.network_key, 16);
    if (cJSON_IsString(tckey)) hex_to_bytes(tckey->valuestring, cfg.tc_link_key, 16);

    write_network_config_to_nvs(&cfg);
    ESP_LOGI(TAG, "Re-applied network config via MQTT command");

    cJSON *correlation_id = cJSON_GetObjectItem(root, "correlation_id");
    cJSON *ack = cJSON_CreateObject();
    cJSON_AddStringToObject(ack, "device_id", DEVICE_ID);
    if (cJSON_IsString(correlation_id)) {
        cJSON_AddStringToObject(ack, "correlation_id", correlation_id->valuestring);
    }
    cJSON_AddStringToObject(ack, "result", "success");
    cJSON_AddStringToObject(ack, "new_role", "coordinator");
    char *body = cJSON_PrintUnformatted(ack);
    char topic[128];
    topic_ack(topic, sizeof(topic));
    esp_mqtt_client_publish(s_mqtt_client, topic, body, 0, 1, 0);
    cJSON_Delete(ack);
    free(body);
}

static void mqtt_event_handler(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data)
{
    esp_mqtt_event_handle_t event = event_data;

    switch (event_id) {
    case MQTT_EVENT_CONNECTED: {
        ESP_LOGI(TAG, "MQTT connected");
        s_mqtt_connected = true;

        char cmd_topic[128], announce_topic[128], status_topic[128];
        topic_command(cmd_topic, sizeof(cmd_topic));
        topic_announce(announce_topic, sizeof(announce_topic));
        topic_status(status_topic, sizeof(status_topic));

        esp_mqtt_client_subscribe(s_mqtt_client, cmd_topic, 1);
        esp_mqtt_client_subscribe(s_mqtt_client, announce_topic, 1);

        const char *msg = "{\"event\":\"booted\",\"role\":\"coordinator\"}";
        esp_mqtt_client_publish(s_mqtt_client, status_topic, msg, 0, 1, 0);
        publish_heartbeat();
        break;
    }

    case MQTT_EVENT_DISCONNECTED:
        ESP_LOGW(TAG, "MQTT disconnected");
        s_mqtt_connected = false;
        break;

    case MQTT_EVENT_DATA: {
        char topic[128] = {0};
        char cmd_topic[128];
        topic_command(cmd_topic, sizeof(cmd_topic));
        size_t topic_len = event->topic_len < sizeof(topic) - 1 ? event->topic_len : sizeof(topic) - 1;
        memcpy(topic, event->topic, topic_len);

        if (strcmp(topic, cmd_topic) == 0) {
            cJSON *root = cJSON_ParseWithLength(event->data, event->data_len);
            if (!root) { ESP_LOGE(TAG, "Bad command JSON"); break; }
            cJSON *command = cJSON_GetObjectItem(root, "command");
            if (cJSON_IsString(command) && strcmp(command->valuestring, "become_coordinator") == 0) {
                handle_become_coordinator(root);
            }
            cJSON_Delete(root);
        } else {
            ESP_LOGI(TAG, "Failover announcement received (ignored, we're the current coordinator)");
        }
        break;
    }

    default:
        break;
    }
}

static void mqtt_init(void)
{
    esp_mqtt_client_config_t mqtt_cfg = {
        .broker.address.uri = MQTT_BROKER_URI,
    };
    s_mqtt_client = esp_mqtt_client_init(&mqtt_cfg);
    esp_mqtt_client_register_event(s_mqtt_client, ESP_EVENT_ANY_ID, mqtt_event_handler, NULL);
    esp_mqtt_client_start(s_mqtt_client);
}

/* ---------------------------------------------------------------------
 * Zigbee: form network as coordinator
 * ------------------------------------------------------------------- */
static void esp_zb_task(void *pvParameters)
{
    esp_zb_cfg_t zb_nwk_cfg = {
        .esp_zb_role = ESP_ZB_DEVICE_TYPE_COORDINATOR,
        .install_code_policy = false,
        .nwk_cfg.zczr_cfg = {
            .max_children = 10,
        },
    };
    esp_zb_init(&zb_nwk_cfg);

    esp_zb_set_primary_network_channel_set(ZB_PRIMARY_CHANNEL_MASK);

    ESP_ERROR_CHECK(esp_zb_start(false));
    esp_zb_stack_main_loop();
}

/* Called by the Zigbee stack when network formation / signals occur.
 * esp-zigbee-sdk requires this callback to be implemented by the app. */
void esp_zb_app_signal_handler(esp_zb_app_signal_t *signal_struct)
{
    uint32_t *p_sg_p = signal_struct->p_app_signal;
    esp_err_t err_status = signal_struct->esp_err_status;
    esp_zb_app_signal_type_t sig_type = *p_sg_p;

    switch (sig_type) {
    case ESP_ZB_ZDO_SIGNAL_SKIP_STARTUP:
        ESP_LOGI(TAG, "Zigbee stack initialized, forming network...");
        esp_zb_bdb_start_top_level_commissioning(ESP_ZB_BDB_MODE_INITIALIZATION);
        break;

    case ESP_ZB_BDB_SIGNAL_FORMATION:
        if (err_status == ESP_OK) {
            esp_zb_ieee_addr_t extended_pan_id;
            esp_zb_get_extended_pan_id(extended_pan_id);
            uint16_t pan_id = esp_zb_get_pan_id();
            uint8_t channel = esp_zb_get_current_channel();

            ESP_LOGI(TAG, "Network formed! PAN ID: 0x%04X, channel: %d", pan_id, channel);

            /* Persist what we formed with, same struct/partition used
             * elsewhere in this project's save/restore + failover flow. */
            zigbee_network_config_t cfg = {0};
            memcpy(cfg.extended_pan_id, extended_pan_id, 8);
            cfg.pan_id = pan_id;
            cfg.channel = channel;
            /* Network key / TC link key: for a from-scratch formation the
             * stack generates these internally; reading them back out
             * requires esp_zb_secur_network_key_get() (SDK-version
             * dependent API name) — left as a follow-up once you confirm
             * the exact function available in esp-zigbee-lib 2.0.3. */

            write_network_config_to_nvs(&cfg);
            s_zigbee_network_formed = true;

            esp_zb_bdb_start_top_level_commissioning(ESP_ZB_BDB_MODE_NETWORK_STEERING);
        } else {
            ESP_LOGW(TAG, "Network formation failed, retrying...");
            esp_zb_scheduler_alarm((esp_zb_callback_t)esp_zb_bdb_start_top_level_commissioning,
                                    ESP_ZB_BDB_MODE_INITIALIZATION, 1000);
        }
        break;

    case ESP_ZB_BDB_SIGNAL_STEERING:
        if (err_status == ESP_OK) {
            ESP_LOGI(TAG, "Network steering complete — ready for routers/end devices to join");
        }
        break;

    default:
        ESP_LOGD(TAG, "Zigbee signal: %d, status: %d", sig_type, err_status);
        break;
    }
}

/* ---------------------------------------------------------------------
 * app_main
 * ------------------------------------------------------------------- */
void app_main(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());
    //*ESP_ERROR_CHECK(nvs_flash_init_partition(ZB_NVS_PART));*//

    xTaskCreate(led_task, "led_task", 2048, NULL, 3, NULL);

    wifi_init_sta();
    mqtt_init();

    xTaskCreate(heartbeat_task, "heartbeat_task", 4096, NULL, 4, NULL);

    /* Zigbee stack needs its own task per esp-zigbee-sdk convention */
    esp_zb_platform_config_t platform_config = {
        .radio_config = { .radio_mode = ZB_RADIO_MODE_NATIVE },
        .host_config = { .host_connection_mode = ZB_HOST_CONNECTION_MODE_NONE },
    };
    ESP_ERROR_CHECK(esp_zb_platform_config(&platform_config));
    xTaskCreate(esp_zb_task, "zigbee_task", 8192, NULL, 5, NULL);

    ESP_LOGI(TAG, "app_main complete, coordinator initializing in background");
}
