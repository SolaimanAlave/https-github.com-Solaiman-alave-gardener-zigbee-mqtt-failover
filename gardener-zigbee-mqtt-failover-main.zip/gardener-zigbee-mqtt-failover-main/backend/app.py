"""
Tiny REST bridge between the two simulated ESP32 devices and Postgres.

Device A (writer)  -> POST /api/nvs/save  -> writes the NVS blob into Postgres
Device B (reader)  -> GET  /api/nvs/load  -> reads the NVS blob back out

Run it with:
    uvicorn app:app --host 0.0.0.0 --port 8000

It must be reachable from the Wokwi simulator's virtual WiFi, so bind to
0.0.0.0 (not 127.0.0.1) and use your machine's LAN IP address in the
firmware, not "localhost". See the README for details.
"""
import os

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import psycopg2
import psycopg2.extras

DB_DSN = os.environ.get(
    "DATABASE_URL",
    "dbname=zigbee_poc user=postgres password=root host=localhost port=5432",
)

app = FastAPI(title="Zigbee NVS Save/Restore POC")


class NvsPayload(BaseModel):
    device_id: str
    nvs_blob_base64: str


def get_conn():
    return psycopg2.connect(DB_DSN)


@app.on_event("startup")
def init_db():
    conn = get_conn()
    with conn.cursor() as cur:
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS zigbee_nvs_backup (
                device_id       TEXT PRIMARY KEY,
                nvs_blob_base64 TEXT NOT NULL,
                updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
            )
            """
        )
    conn.commit()
    conn.close()


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/api/nvs/save")
def save_nvs(payload: NvsPayload):
    conn = get_conn()
    with conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO zigbee_nvs_backup (device_id, nvs_blob_base64, updated_at)
            VALUES (%s, %s, now())
            ON CONFLICT (device_id)
            DO UPDATE SET nvs_blob_base64 = EXCLUDED.nvs_blob_base64,
                          updated_at = now()
            """,
            (payload.device_id, payload.nvs_blob_base64),
        )
    conn.commit()
    conn.close()
    return {"status": "saved", "device_id": payload.device_id}


@app.get("/api/nvs/load")
def load_nvs(device_id: str):
    conn = get_conn()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            "SELECT device_id, nvs_blob_base64, updated_at "
            "FROM zigbee_nvs_backup WHERE device_id = %s",
            (device_id,),
        )
        row = cur.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="No backup found for that device_id")
    row["updated_at"] = row["updated_at"].isoformat()
    return row
