-- Run once against your Postgres database (the FastAPI app also
-- creates this automatically on startup, this file is here so you
-- can inspect / run it manually with psql if you prefer).

CREATE TABLE IF NOT EXISTS zigbee_nvs_backup (
    device_id       TEXT PRIMARY KEY,
    nvs_blob_base64 TEXT NOT NULL,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
