/*
 * Device B - "Reader / Restorer"
 *
 * Fetches the NVS blob that Device A saved to Postgres, and writes it
 * into ITS OWN "zb_storage" NVS partition. In a real deployment this is
 * the step that lets a replacement radio come up already knowing the
 * network's PAN ID / channel / keys, instead of having to re-commission
 * from scratch.
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "esp_http_client.h"
#include "mbedtls/base64.h"
#include "cJSON.h"

/* ---- Edit these two for your setup ------------------------------- */
#define WIFI_SSID      "Wokwi-GUEST"
#define WIFI_PASS      ""
#define BACKEND_HOST   "10.0.0.21"    /* <-- your machine's LAN IP  */
#define BACKEND_PORT   8000
/* -------------------------------------------------------------------*/

#define SOURCE_DEVICE_ID "zigbee-device-A"   /* whose backup we restore */
#define ZB_NVS_PART       "zb_storage"
#define ZB_NVS_NS         "zdo"
#define ZB_NVS_KEY        "zb_data"

static const char *TAG = "device_b_reader";
static EventGroupHandle_t s_wifi_event_group;
#define WIFI_CONNECTED_BIT BIT0

typedef struct __attribute__((packed)) {
    uint8_t  extended_pan_id[8];
    uint16_t pan_id;
    uint8_t  channel;
    uint16_t short_addr;
    uint8_t  network_key[16];
    uint8_t  tc_link_key[16];
    uint8_t  device_role;
} zigbee_nvs_data_t;

static void wifi_event_handler(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        ESP_LOGW(TAG, "WiFi disconnected, retrying...");
        esp_wifi_connect();
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *event = (ip_event_got_ip_t *) data;
        ESP_LOGI(TAG, "Got IP: " IPSTR, IP2STR(&event->ip_info.ip));
        xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
    }
}

static void wifi_init_sta(void)
{
    s_wifi_event_group = xEventGroupCreate();
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &wifi_event_handler, NULL));

    wifi_config_t wifi_config = {
        .sta = {
            .ssid = WIFI_SSID,
            .password = WIFI_PASS,
        },
    };
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());

    ESP_LOGI(TAG, "Connecting to WiFi SSID:%s", WIFI_SSID);
    xEventGroupWaitBits(s_wifi_event_group, WIFI_CONNECTED_BIT, pdFALSE, pdTRUE, portMAX_DELAY);
}

/* Returns a malloc'd buffer with the HTTP response body, or NULL. */
static char *http_get(const char *url)
{
    esp_http_client_config_t config = {
        .url = url,
        .method = HTTP_METHOD_GET,
        .timeout_ms = 8000,
    };
    esp_http_client_handle_t client = esp_http_client_init(&config);
    esp_err_t err = esp_http_client_open(client, 0);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "HTTP open failed: %s", esp_err_to_name(err));
        esp_http_client_cleanup(client);
        return NULL;
    }

    int content_length = esp_http_client_fetch_headers(client);
    int status = esp_http_client_get_status_code(client);
    ESP_LOGI(TAG, "GET %s -> HTTP %d", url, status);

    if (content_length <= 0) {
        esp_http_client_close(client);
        esp_http_client_cleanup(client);
        return NULL;
    }

    char *buf = malloc(content_length + 1);
    int read_len = esp_http_client_read(client, buf, content_length);
    if (read_len < 0) {
        free(buf);
        buf = NULL;
    } else {
        buf[read_len] = '\0';
    }

    esp_http_client_close(client);
    esp_http_client_cleanup(client);
    return buf;
}

static bool fetch_and_restore_nvs(void)
{
    char url[192];
    snprintf(url, sizeof(url), "http://%s:%d/api/nvs/load?device_id=%s",
             BACKEND_HOST, BACKEND_PORT, SOURCE_DEVICE_ID);

    char *body = http_get(url);
    if (!body) {
        ESP_LOGE(TAG, "No response body from backend");
        return false;
    }

    cJSON *root = cJSON_Parse(body);
    free(body);
    if (!root) {
        ESP_LOGE(TAG, "Failed to parse JSON response");
        return false;
    }

    cJSON *blob_field = cJSON_GetObjectItem(root, "nvs_blob_base64");
    if (!cJSON_IsString(blob_field)) {
        ESP_LOGE(TAG, "Response had no nvs_blob_base64 field (device not backed up yet?)");
        cJSON_Delete(root);
        return false;
    }

    const char *b64 = blob_field->valuestring;
    size_t decoded_len = 0;
    mbedtls_base64_decode(NULL, 0, &decoded_len, (const unsigned char *) b64, strlen(b64));
    uint8_t *decoded = malloc(decoded_len);
    mbedtls_base64_decode(decoded, decoded_len, &decoded_len, (const unsigned char *) b64, strlen(b64));

    nvs_handle_t h;
    ESP_ERROR_CHECK(nvs_open_from_partition(ZB_NVS_PART, ZB_NVS_NS, NVS_READWRITE, &h));
    ESP_ERROR_CHECK(nvs_set_blob(h, ZB_NVS_KEY, decoded, decoded_len));
    ESP_ERROR_CHECK(nvs_commit(h));
    nvs_close(h);

    if (decoded_len == sizeof(zigbee_nvs_data_t)) {
        zigbee_nvs_data_t *zb = (zigbee_nvs_data_t *) decoded;
        ESP_LOGI(TAG, "Restored Zigbee identity from Postgres:");
        ESP_LOGI(TAG, "  PAN ID:       0x%04X", zb->pan_id);
        ESP_LOGI(TAG, "  Channel:      %d", zb->channel);
        ESP_LOGI(TAG, "  Short addr:   0x%04X", zb->short_addr);
        ESP_LOGI(TAG, "  Device role:  %d", zb->device_role);
    } else {
        ESP_LOGW(TAG, "Restored %d bytes (unexpected size, but write succeeded)", (int) decoded_len);
    }

    free(decoded);
    cJSON_Delete(root);
    return true;
}

static void verify_restore(void)
{
    nvs_handle_t h;
    esp_err_t err = nvs_open_from_partition(ZB_NVS_PART, ZB_NVS_NS, NVS_READONLY, &h);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Could not reopen '%s' for verification: %s", ZB_NVS_PART, esp_err_to_name(err));
        return;
    }
    size_t len = 0;
    err = nvs_get_blob(h, ZB_NVS_KEY, NULL, &len);
    if (err == ESP_OK) {
        ESP_LOGI(TAG, "Verification OK: '%s'/'%s' now holds %d bytes on Device B",
                 ZB_NVS_PART, ZB_NVS_KEY, (int) len);
    } else {
        ESP_LOGE(TAG, "Verification failed: %s", esp_err_to_name(err));
    }
    nvs_close(h);
}

void app_main(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(nvs_flash_init_partition(ZB_NVS_PART));

    wifi_init_sta();

    if (fetch_and_restore_nvs()) {
        verify_restore();
        ESP_LOGI(TAG, "Device B is now provisioned with Device A's saved Zigbee identity.");
    } else {
        ESP_LOGE(TAG, "Restore failed - is Device A's data in Postgres yet?");
    }
}
